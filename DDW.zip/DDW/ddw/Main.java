//package ddw;
import javax.swing.JFrame;

public class Main{
	public static void main(String... args){
		new GameFrame();
	}
}

/*
##########Credits##########

-----Sound-----
--Start/Menu Screen
Author: skrjablin
Site: 'https://opengameart.org/content/melodic-adventure-theme-and-rhythmic-variation-c64-style'

--Battle Screen
Author:mattslifka
Site: 'https://mslifka12.itch.io/pixel-blasters'

-----Character Imagens-----
Author: wulax
Site: 'https://opengameart.org/content/lpc-medieval-fantasy-character-sprites'

-----Sign Post------
Author:Nemisys
Site: 'https://opengameart.org/content/lpc-sign-post'

----Start Screen Background----
Author: iSohei 'isohei.deviantart.com' 'https://isohei.deviantart.com/art/Pixel-Waterfall-BG-298403583'
Site: 'https://orig00.deviantart.net/879c/f/2012/119/1/0/pixel_waterfall_bg__by_isohei-d4xntof.gif'

----Logo----
Author:Pâmela da Silva Souza (Animação 2018.1 UFSC)

----Battle Screen Background----
Author:
Site: 'https://edermunizz.itch.io/free-pixel-art-forest'
Modification:Victor Macario Shumman

*/

